/**
 * Initial Bootstrap Tooltip.
*/
$(function () {
  $("[data-toggle=\"tooltip\"]").tooltip();
});
